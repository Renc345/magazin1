﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fishshop.Classes;

namespace Fishshop.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageFish.xaml
    /// </summary>
    public partial class PageFish : Page
    {
        public PageFish()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.ToList();
            CMBFilterFish.Items.Add("От 10 до 100");
            CMBFilterFish.Items.Add("От 101 до 500");
            CMBFilterFish.Items.Add("От 501 до 1000");
        }

        private void CMBFilterFish_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CMBFilterFish.SelectedIndex == 0)
                DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x=>x.Price >= 10 && x.Price <= 100).ToList();
            else if (CMBFilterFish.SelectedIndex == 1)
                DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x => x.Price >= 101 && x.Price <= 500).ToList();
            else
                DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x => x.Price >= 501 && x.Price <= 1000).ToList();
        }

        private void FindFish_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x => x.Name.ToLower().Contains(FindFish.Text.ToLower())).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.OrderByDescending(x => x.Name).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.OrderBy(x => x.Name).ToList();
        }
        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new Glavmenu());
        }
    }
}
