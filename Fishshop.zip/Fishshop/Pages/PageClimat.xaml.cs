﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fishshop.Classes;


namespace Fishshop.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageClimat.xaml
    /// </summary>
    public partial class PageClimat : Page
    {
        public PageClimat()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = PetShopEntities.GetContext().HabitatClimate.ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().HabitatClimate.OrderBy(x => x.HabitatClimatee).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().HabitatClimate.OrderByDescending(x => x.HabitatClimatee).ToList();
        }

        private void FindClimat_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().HabitatClimate.Where(x => x.HabitatClimatee.ToLower().Contains(FindClimat.Text.ToLower())).ToList();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new Glavmenu());
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
